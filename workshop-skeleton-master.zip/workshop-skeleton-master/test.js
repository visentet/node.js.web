try {
	require('server');
} catch(err) {
	return console.error(err.message);
}
console.log("Congrats, you've everything ready for the workshop");

